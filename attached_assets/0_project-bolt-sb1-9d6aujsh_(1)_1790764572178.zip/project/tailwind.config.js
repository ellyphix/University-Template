/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        body: ['"Source Sans 3"', 'sans-serif'],
      },
      colors: {
        cardinal: {
          50: '#FBF3F3',
          100: '#F7E8E8',
          200: '#EFCFCF',
          300: '#E0AEAE',
          400: '#C97D7D',
          500: '#A84F4F',
          600: '#8C1515',
          700: '#761010',
          800: '#5E0D0D',
          900: '#4A0A0A',
        },
        stone: {
          50: '#FAF9F7',
          100: '#F5F3EF',
          200: '#EAE6DF',
          300: '#D8D2C7',
          400: '#B8AE9E',
          500: '#948A78',
          600: '#736B5E',
          700: '#544F46',
          800: '#3A3631',
          900: '#221F1C',
        },
      },
      letterSpacing: {
        tightest: '-0.03em',
        widest: '0.18em',
      },
      maxWidth: {
        '7xl': '80rem',
      },
    },
  },
  plugins: [],
};
